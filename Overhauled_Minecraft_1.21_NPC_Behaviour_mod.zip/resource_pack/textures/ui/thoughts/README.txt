Placeholder thought icons

This folder is a placeholder for Thought UI icon images. Add PNGs (or platform-supported textures) with the following names to map to emotions:

- fear.png
- curious.png
- joy.png
- anger.png
- default.png

After adding images, update `resource_pack/textures/thought_icons.json` if you change paths.
